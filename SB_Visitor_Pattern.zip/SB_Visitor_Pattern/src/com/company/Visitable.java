package com.company;

public interface Visitable {
    public double accept(Visitor visitor);
}
